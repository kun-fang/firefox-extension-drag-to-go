Firefox Addon: Drag To Go
====

I had been using Easy DragToGo (Easy DragToGo++ later years), which I think is the best drag and drop addon on Firefox. Since Firefox required building extensions using WebExtensions APIs in November of 2017, the addon stopped working and no one built a newer version.

This addon is trying to build a duplicate of Easy DragToGo. The current version is a very early version to achieve the simplest functions of Easy DragToGo++
